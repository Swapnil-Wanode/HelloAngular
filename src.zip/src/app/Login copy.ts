export class Login{

    public userId:number;
    public userName:string;
    public password:string;
    
}