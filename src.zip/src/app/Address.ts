export class Address{
    public addressId:number;
    public pincode:number;
}