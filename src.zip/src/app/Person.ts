export class Person{

    public pid: number=0;
    public pname: string='null';
    public page: number=0;

    // Person(pid:number, pname:string,page:number){
    //     this.pid=pid;
    //     this.pname=pname;
    //     this.page=page;
    // }

}