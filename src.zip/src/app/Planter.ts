export class Planter{
    
	
	public planterId : number;
	
    public planterHeight : number;
	
	public planterCapacity : number;
	
	public drainageHoles : number;
	
	public planterColour : string;
	
	public planterShape : string;
	
	public planterStock : number;
	
	public planterCost : number;

}