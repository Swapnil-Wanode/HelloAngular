export class Order{
    public  bookingOrderId: number;
	
	public  orderDate:string;
	
	public  transactionMode:string;
	
	public quantity:number;
	
	public totalCost:number;	
	
	//public planters:Planter[];
	
    // public plants:Plant[];
    
	// public seeds:Seed[];

	//public customer:Customer[];
}