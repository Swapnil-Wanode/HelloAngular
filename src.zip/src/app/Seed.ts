export class Seed{
    public seedId:number
    public  commonName:string
    public bloomTime:string
    public watering:string
    public difficultyLevel:string
    public temperature:string
    public typeOfSeeds:string
    public seedsDescription:string
    public seedsStock:number
    public seedsCost:number
    public seedsPerPacket:number
   
 
}