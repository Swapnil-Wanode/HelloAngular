export class Plant {

   public plantId: number;

   public plantHeight: number;

   public plantSpread: string;

   public commonName: string;

   public bloomTime: string;

   public medicinalOrCulinaryUse: string

   public difficultyLevel: string;

   public temparature: string;

   public typeOfPlant: string;

   public plantDescription: string;

   public plantsStock: number;

   public plantCost: number;
}